<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{validatecustomer}prestashop>needactivation_06c058f1f1093df1aff40018b0b4b68b'] = 'Ditt konto måste godkännas av en adminstratör innan du kan logga in efter registrering';
$_MODULE['<{validatecustomer}prestashop>validate_06c058f1f1093df1aff40018b0b4b68b'] = 'Du kommer inom kort bli kontaktad av en av våra representatner som även kommer aktivera ditt konto.';
$_MODULE['<{validatecustomer}prestashop>validate_779dc10debb9ab278f3f9e0c87e111d8'] = 'Om du vill ha svart direkt, ring';
$_MODULE['<{validatecustomer}prestashop>validate_f6d4fb7829232a865da5c4d9f786387d'] = 'Hej. <br><br>Vi är väldigt glada att ni har valt att registrera ett konto hos oss';